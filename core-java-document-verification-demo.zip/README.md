# DocuCheck — Core Java Document Verification Demo

A mobile-friendly college demo using only the JDK: built-in `HttpServer`, collections, records, form parsing and SHA-256. No Spring Boot, Maven, MySQL or external Java libraries.

## Demo IDs
- Aadhaar sample: `DEMO-AADHAAR-001`
- PAN sample: `DEMO-PAN-001`
- Driving licence sample: `DEMO-DL-001`
- Education certificate sample: `DEMO-CERT-001`

Choose the corresponding document type and ID.

## Important
This is simulated sample-record matching only. It does NOT verify real Aadhaar, PAN, driving licences, QR signatures or government records. Never enter real identity numbers or upload real identity documents. SHA-256 is only a fingerprint of the demo record, not proof of government issuance. Records are stored in memory and reset when the server restarts.

## Run locally (JDK 17+)
```bash
javac --add-modules jdk.httpserver -d out src/Main.java
java --add-modules jdk.httpserver -cp out Main
```
Open `http://localhost:8080`.

## Deploy publicly from Android using GitHub + Render
1. Create/sign in to GitHub using your phone browser.
2. Create a repository, e.g. `core-java-document-demo`.
3. Upload `Dockerfile`, `README.md`, and the `src` folder (containing `Main.java`) from this ZIP.
4. Sign in to Render and connect GitHub.
5. Select **New → Web Service**, then choose your repository.
6. Select **Docker** as the runtime. Render should detect the Dockerfile.
7. Create the service and wait for deployment.
8. Open the HTTPS `onrender.com` URL shown in the Render dashboard.

The app listens on `0.0.0.0` and reads the hosting platform's `PORT` variable. Free hosting availability and sleep policies may change; check the current dashboard.

## OOP concepts
- Class and object: `Main` and `DemoDocument` record objects.
- Encapsulation: `DemoDocument` groups sample document fields.
- Abstraction: helper methods hide parsing, hashing and response handling.
- Collections: `HashMap` stores and retrieves sample records.
- Exception handling: I/O and hashing errors are handled.

For real identity verification, use only official/authorized methods, obtain consent, minimize data and follow applicable law.
