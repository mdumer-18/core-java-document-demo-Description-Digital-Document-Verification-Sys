import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.Executors;

public class Main {
    private static final Map<String, DemoDocument> RECORDS = new HashMap<>();

    public static void main(String[] args) throws Exception {
        add("AADHAAR", "DEMO-AADHAAR-001", "Sample User One", "Sample Aadhaar-style record", "2026-01-15");
        add("PAN", "DEMO-PAN-001", "Sample User Two", "Sample PAN record", "2025-11-20");
        add("DRIVING LICENCE", "DEMO-DL-001", "Sample User Three", "Sample driving licence record", "2024-08-10");
        add("EDUCATION CERTIFICATE", "DEMO-CERT-001", "Sample Student", "Bachelor of Technology", "2025-06-30");

        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.createContext("/", Main::handle);
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        System.out.println("DocuCheck running on port " + port);
    }

    private static void add(String type, String id, String name, String detail, String date) {
        RECORDS.put(key(type, id), new DemoDocument(type, id, name, detail, date));
    }

    private static String key(String type, String id) {
        return type.trim().toUpperCase() + "|" + id.trim().toUpperCase();
    }

    private static void handle(HttpExchange ex) throws IOException {
        headers(ex);
        if ("GET".equalsIgnoreCase(ex.getRequestMethod())) {
            send(ex, 200, page(""));
            return;
        }
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            ex.getResponseHeaders().set("Allow", "GET, POST");
            send(ex, 405, page("<p class='bad'>Method not allowed.</p>"));
            return;
        }

        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> form = parse(body);
        String type = form.getOrDefault("documentType", "");
        String id = form.getOrDefault("documentId", "").trim();

        if (type.isBlank() || id.isBlank()) {
            send(ex, 400, page("<p class='bad'>Please select a document type and enter a demo ID.</p>"));
            return;
        }

        DemoDocument d = RECORDS.get(key(type, id));
        if (d == null) {
            send(ex, 200, page("<section class='result bad'><b>NO SAMPLE RECORD FOUND</b><p>This demo cannot confirm whether a real document is genuine.</p></section>"));
            return;
        }

        String fingerprint = sha256(d.type + "|" + d.id + "|" + d.name + "|" + d.detail + "|" + d.issueDate);
        String result = "<section class='result good'><b>✓ SAMPLE RECORD MATCHED</b>"
                + "<p class='warning'>Simulated college-project result only. This is NOT official Aadhaar, PAN or government verification.</p>"
                + "<p><b>Document:</b> " + esc(d.type) + "</p>"
                + "<p><b>Demo ID:</b> " + esc(d.id) + "</p>"
                + "<p><b>Sample name:</b> " + esc(d.name) + "</p>"
                + "<p><b>Details:</b> " + esc(d.detail) + "</p>"
                + "<p><b>Sample issue date:</b> " + esc(d.issueDate) + "</p>"
                + "<p><b>SHA-256 fingerprint:</b><code>" + fingerprint + "</code></p></section>";
        send(ex, 200, page(result));
    }

    private static Map<String, String> parse(String body) {
        Map<String, String> map = new HashMap<>();
        for (String pair : body.split("&")) {
            String[] p = pair.split("=", 2);
            String k = URLDecoder.decode(p[0], StandardCharsets.UTF_8);
            String v = p.length > 1 ? URLDecoder.decode(p[1], StandardCharsets.UTF_8) : "";
            map.put(k, v);
        }
        return map;
    }

    private static String sha256(String text) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) { return "Unavailable"; }
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private static String page(String result) {
        return """
        <!doctype html><html lang="en"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        <title>DocuCheck | Document Verification Demo</title>
        <style>
        *{box-sizing:border-box}body{margin:0;background:#f3f6fb;color:#203047;font-family:Arial,sans-serif}
        header{background:white;padding:18px max(18px,calc((100% - 760px)/2));border-bottom:1px solid #dce4ef}
        .brand{font-size:22px;font-weight:800;color:#142d4e}.brand span{color:#2864dc}
        main{max-width:680px;margin:38px auto;padding:0 16px}.intro{text-align:center;margin-bottom:25px}
        .eyebrow{font-size:11px;letter-spacing:2px;color:#2864dc;font-weight:bold}
        h1{font-size:clamp(29px,6vw,42px);color:#142d4e;margin:12px 0}
        .sub{color:#64748b;line-height:1.6}.card{background:white;border:1px solid #dce4ef;border-radius:16px;padding:24px}
        h2{color:#142d4e;margin-top:0}label{display:block;font-weight:bold;margin:15px 0 7px}
        select,input{width:100%;padding:13px;border:1px solid #cbd5e1;border-radius:9px;font-size:16px;background:white}
        button{width:100%;padding:14px;margin-top:20px;border:0;border-radius:9px;background:#2864dc;color:white;font-weight:bold;font-size:16px}
        .warning{padding:12px;background:#fff5d9;border-radius:9px;color:#765500;font-size:13px;line-height:1.5}
        .examples{background:#f7f9fc;padding:14px;border-radius:9px;font-size:13px;line-height:1.9;margin-top:17px}
        code{overflow-wrap:anywhere;font-size:12px;color:#53647a}.result{margin-top:20px;padding:18px;border-radius:12px;background:white}
        .good{border:1px solid #91d4ae;background:#f2fff7;color:#087443}.bad{border:1px solid #efb2b2;background:#fff5f5;color:#a51e1e}
        .result p{color:#26384d;line-height:1.5}footer{text-align:center;color:#64748b;font-size:12px;padding:25px}
        @media(max-width:520px){main{margin:24px auto}.card{padding:19px}}
        </style></head><body>
        <header><div class="brand">Docu<span>Check</span></div></header>
        <main><div class="intro"><div class="eyebrow">CORE JAVA COLLEGE PROJECT</div>
        <h1>Digital Document Verification</h1>
        <p class="sub">Check sample Aadhaar-style, PAN, driving licence and education certificate records.</p></div>
        <section class="card"><h2>Verify a document record</h2>
        <div class="warning"><b>Privacy notice:</b> Do not enter real Aadhaar, PAN or driving licence numbers. Do not upload real identity documents. This demo uses sample records only and is not connected to UIDAI or any government database.</div>
        <form method="post" action="/">
        <label for="documentType">Document type</label><select id="documentType" name="documentType" required>
        <option value="">Choose document</option><option value="AADHAAR">Aadhaar (sample)</option>
        <option value="PAN">PAN (sample)</option><option value="DRIVING LICENCE">Driving Licence (sample)</option>
        <option value="EDUCATION CERTIFICATE">Education Certificate</option></select>
        <label for="documentId">Demo document ID</label><input id="documentId" name="documentId" placeholder="DEMO-AADHAAR-001" required>
        <button type="submit">Check sample record</button></form>
        <div class="examples"><b>Try these sample IDs</b><br>Aadhaar: <code>DEMO-AADHAAR-001</code><br>
        PAN: <code>DEMO-PAN-001</code><br>Driving Licence: <code>DEMO-DL-001</code><br>
        Education: <code>DEMO-CERT-001</code></div></section>
        """ + result + """
        </main><footer>DocuCheck · Core Java HTTP Server · Demonstration only</footer></body></html>
        """;
    }

    private static void headers(HttpExchange ex) {
        ex.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        ex.getResponseHeaders().set("X-Frame-Options", "DENY");
        ex.getResponseHeaders().set("Referrer-Policy", "no-referrer");
        ex.getResponseHeaders().set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
    }

    private static void send(HttpExchange ex, int status, String html) throws IOException {
        byte[] data = html.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, data.length);
        ex.getResponseBody().write(data);
        ex.close();
    }

    private record DemoDocument(String type, String id, String name, String detail, String issueDate) {}
}
